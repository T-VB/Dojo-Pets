#create a Ninja class with given attributes
class Ninja:
    def __init__(self, first_name, last_name, treats, pet_food, pet):
        self.first_name = first_name
        self.last_name = last_name
        self.treats = treats
        self.pet_food = pet_food
        self.pet = Pet
    
    def walk(self):
        self.pet.play()
        return self

    def feed(self):
        self.pet.eat() #if len(self.pet_food) > 0:   #if, else
        return self        #self.pet.eat()
                       #print("hungry!")
                       #return self

    def bathe(self):
        self.pet.noise
        return self

    
#create a Pet class with given attributes
class Pet:
    def __init__(self, name, species, tricks, noise):
        self.name = name
        self.species = species
        self.tricks = tricks
        self.health = 100
        self.energy = 30
        self.noise = noise

    #increases pet energy by 25
    def sleep(self):
        self.energy += 25
        return self

    #increases pet energy by 5 and health by 10
    def eat(self):
        self.energy += 5
        self.health += 10
        return self

    #increases pet health by 5, decrease energy by 10
    def play(self):
        self.health += 5
        self.energy -= 10
        return self
    
    #prints out the pet's sound (add to blueprint)
    def noise(self):
        print(self.noise)

pet_treats = ["bone", "cookie", "greenie"] #create var pet_treats that creates a list of treats
tasty_pet_food = ["Purina", "Nature's Wilderness"] #create var that creates a list of pet food

Champ = Pet("Champ", "Husky", ['shakes', 'barks'], "Ruff") #create pet Champ name: Champ, species: Husky, tricks[], noise: Ruff

Tyler = Ninja("Tyler", "Vander Boegh", pet_treats, tasty_pet_food, Champ) #create Ninja

'''
def feed(self)
    if len(self.pet_food) > 0:     #if, else
        food = self.pet_food.pop()      #takes away last food in list, assign var
        print(f"Feeding {self.pet.name} {food}")    #f string feeding name and the food that was popped from list
        self.pet.eat()
    else:
        print("hungry!")
    return self
'''

Tyler.feed()

import exotic_pets
