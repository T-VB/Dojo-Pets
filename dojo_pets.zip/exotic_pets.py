class Exotics: [
    {'species:''Lion', 'name:''Gryffindor'}
    {'species:''Snake', 'name:''Slytherin'}
]